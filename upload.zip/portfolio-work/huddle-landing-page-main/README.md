# huddle-landing-page
Example landing page for Huddle messenger service
This is a front end mentor project. 
Technology used in this project: HTML5, CSS3, Bootstrap 4
