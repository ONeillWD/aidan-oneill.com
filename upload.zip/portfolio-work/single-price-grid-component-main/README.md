# single-price-grid-component
Single price responsive component
This is a single price component built with bootstrap. Example build, inactive.
